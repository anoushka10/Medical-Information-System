var billt;
var gstt;
var tott;
alert(hello);

function dobill() {
    //alert("hello bill")
    var ut = document.frm.texunit.value;
    var lt = document.frm.texload.value;

    //alert(ut+""+lt);
    var u = isNaN(ut);
    var l = isNaN(lt);
    if(u==true)
        document.frm.texunit.style.backgroundColor="red";
        else
            document.frm.texunit.style.backgroundColor="white";
    if(l==true)
        document.frm.texload.style.backgroundColor="red";
        else
            document.frm.texload.style.backgroundColor="white";
    if (u == false && l == false) {
        billt = parseFloat(ut) * 10 + parseFloat(lt) * 100;
        document.frm.texbill.value = billt;
        document.frm.btnbill.disabled=false;
        
        
    }

}

function dogst() {
    //alert(billt);
    gstt = (18 * billt) / 100;
    document.frm.texgst.value = gstt;
    
    document.frm.btngst.disabled=false;
}

function dototal() {

    tott = billt + gstt;
    document.frm.textot.value = tott;
}

function doNew() {
    //alert();
    document.frm.texunit.value = "";
    document.frm.texload.value = "";
    document.frm.texbill.value = "";
    document.frm.texgst.value = "";
    document.frm.textot.value = "";

}
